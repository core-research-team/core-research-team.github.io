""" hello.py """

import logging
import socket

from flask import Flask, request, jsonify, redirect

log = logging.getLogger(__name__)
app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def main():
    # the next line is required for Transfer-Encoding support in the request
    request.environ['wsgi.input_terminated'] = True
    headers = {}
    for header in request.headers:
        headers[header[0]] = header[1]
    return jsonify(body=request.data, headers=headers)

@app.route('/redirect', methods=['GET'])
def redir():
    url = request.args.get('url')
    return redirect(url)

@app.route('/xss', methods=['GET'])
def xss():
    payload = request.args.get('xss')
    return payload

if __name__ == '__main__':
    app.run(host='0.0.0.0')
