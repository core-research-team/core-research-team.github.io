curl http://192.168.47.1:8888/FiddlerRoot.cer --output foo.cer
openssl x509 -inform DER -in foo.cer -out fiddler_200424.crt
cp fiddler_200424.crt /usr/share/ca-certificates/extra/
dpkg-reconfigure ca-certificates