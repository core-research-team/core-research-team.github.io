import urlparse
import urllib

def mutation(params):
    params_arr = urlparse.parse_qsl(params)
    rules = [
        "'", 
        '"',
    ]

    mutations = []
    for delete in [True, False]:
        for rule in rules:
            for target_key, value in params_arr:
                temp_params = []
                for key, value in params_arr:
                    if key not in ['_'] and value != '' and target_key == key:
                        if delete:
                            temp_params.append((key, value+rule))
                        else:
                            temp_params.append((key, rule))
                    else:
                        temp_params.append((key, value))
                temp = []
                for key, value in temp_params:
                    if value == '':
                        temp.append("{}".format(key))
                    else:
                        temp.append("{}={}".format(key, urllib.quote(value)))
                mutations.append("&".join(temp))
    return mutations

u = urlparse.urlsplit("/kt/events/v1.0/types/P/sections/ALL?limit=12&offset=1&order=evtPstngDate%3ADESC&_=1586839332652")
for mutation_query in mutation(u.query):
    print(mutation_query)
#print(u)